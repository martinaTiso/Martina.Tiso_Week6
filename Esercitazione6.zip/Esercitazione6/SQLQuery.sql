create database GestSpese;

create table Categorie(
IdCateg int primary key identity(1,1),
NomeCategoria nvarchar (50))

create table Spesa(
Id int primary key identity(1,1),
Data Date ,
Descrizione nvarchar(50),
Utente nvarchar (50),
Importo decimal,
Approvata bit,
IdCateg int foreign key references Categorie(IdCateg))


insert into Categorie values('bolletta'),
							('Affitto'),
							('bollo'),
							('Mutuo');

Insert into Spesa values('2021-12-20','Pagamento luce','Martina',50.02,1,1);
insert into Spesa values('2021-11-20','Pagemento affitto mese aprile','Anna',400.03,0,2);
insert into Spesa values('2021-10-20','Pagemento bollo mese aprile','Serena',135,23,1,3);
insert into Spesa values('2021-12-20','Pagemento mutuo mese Dicembre','Davide',512.02,1,4);