﻿using System.Data;
using System.Data.SqlClient;

namespace SupportDisconnected
{
    public class Class1
    {
        public static SqlDataAdapter InitSpesaDataSetAndAdapter(DataSet spesaDs, SqlConnection conn)
        {
            SqlDataAdapter adapter = new SqlDataAdapter();

            //SELECT
            adapter.SelectCommand = GenerateSelectCommand(conn);
            //INSERT
            adapter.InsertCommand = GenerateInsertCommand(conn);
            //UPDATE
            adapter.UpdateCommand = GenerateUpdateCommand(conn);
            //DELETE
            adapter.DeleteCommand = GenerateDeleteCommand(conn);

            //recupero delle informazioni sulla primary key di ogni specifica tabella
            adapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            //primo parametro: dataset -- secondo parametro: nome della tabella nel db
            adapter.Fill(spesaDs, "Spesa");

            return adapter;
        }

        private static SqlCommand GenerateDeleteCommand(SqlConnection conn)
        {
            SqlCommand deleteCommand = new SqlCommand();
            deleteCommand.Connection = conn;
            deleteCommand.CommandType = CommandType.Text;
            deleteCommand.CommandText = "DELETE FROM Spesa WHERE ID = @id";

            deleteCommand.Parameters.Add(new SqlParameter(
                "@id", SqlDbType.Int, 0, "ID"));

            return deleteCommand;
        }
        private static SqlCommand GenerateInsertCommand(SqlConnection conn)
        {
            SqlCommand spesaInsertCommand = new SqlCommand();
            spesaInsertCommand.Connection = conn;
            spesaInsertCommand.CommandType = CommandType.Text;
            spesaInsertCommand.CommandText = "INSERT INTO Spesa VALUES (@descrizione, @utente, @importo)";


            spesaInsertCommand.Parameters.Add(new SqlParameter(
                "@descrizione", SqlDbType.NVarChar, 50, "Descrizione"
            ));
            spesaInsertCommand.Parameters.Add(new SqlParameter(
                "@utente", SqlDbType.NVarChar, 50, "Utente"
            ));
            spesaInsertCommand.Parameters.Add(new SqlParameter(
               "@importo", SqlDbType.Decimal, 0, "importo"
            ));
            return spesaInsertCommand;
        }
        private static SqlCommand GenerateUpdateCommand(SqlConnection conn)
        {
            SqlCommand updateSpesaCommand = new SqlCommand();
            updateSpesaCommand.Connection = conn;
            updateSpesaCommand.CommandType = CommandType.Text;
            updateSpesaCommand.CommandText = "UPDATE Spesa SET Descrizione= @descrizione, " +
                "Utente = @utente, Importo = @importo WHERE ID = @id";

            updateSpesaCommand.Parameters.Add(new SqlParameter(
                "@descrizione", SqlDbType.NVarChar, 50, "descrizione"
                ));
            updateSpesaCommand.Parameters.Add(new SqlParameter(
                "@utente", SqlDbType.NVarChar, 50, "Utente"));
            updateSpesaCommand.Parameters.Add(new SqlParameter(
                "@Importo", SqlDbType.Decimal, 0, "importo"));
            updateSpesaCommand.Parameters.Add(new SqlParameter(
                "@id", SqlDbType.Int, 0, "ID"));

            return updateSpesaCommand;
        }
        private static SqlCommand GenerateSelectCommand(SqlConnection conn)
        {
            SqlCommand spesaSelectCommand = new SqlCommand();
            spesaSelectCommand.Connection = conn;
            spesaSelectCommand.CommandType = CommandType.Text;
            spesaSelectCommand.CommandText = "SELECT * FROM Spesa";

            return spesaSelectCommand;
        }

    }
}